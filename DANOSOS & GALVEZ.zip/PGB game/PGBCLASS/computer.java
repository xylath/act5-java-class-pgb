package PGBCLASS;

public class computer {
    public int score;
    public String choice;
}
