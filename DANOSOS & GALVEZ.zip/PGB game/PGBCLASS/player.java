package PGBCLASS;

public class player {
    public int score;
    public String name;
    public String choice;
}
