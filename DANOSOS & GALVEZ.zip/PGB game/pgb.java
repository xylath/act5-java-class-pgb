//BY KHEE JAY GALVEZ & LEMMUEL DAVE DANOSOS BSCS 2A

import java.util.Random;
import java.util.Scanner;
import PGBCLASS.*;

public class pgb {
    public static void main(String[] args){
        //instantiate classes
            Scanner scan = new Scanner(System.in);
            player player1 = new player();
            computer bot = new computer();
        
        //get the player name
            System.out.print("Enter your name: ");
            player1.name = scan.nextLine();
            System.out.println("\nWelcome to Papel, Gunting, Bato Game!");

        //3 rounds using for loop
        for(int i = 0; i <= 2; i++){

            //get the player choice
                System.out.print("\n------------------------------------------------------------\n");
                System.out.printf("\t\t\tROUND %d\n", i+1);
                System.out.printf("[papel, gunting, or bato], %s enter your choice: ", player1.name);
                player1.choice = scan.nextLine();

            //calls a method that returns a random number corresponds for computer choice
                if(Computer() == 1)
                    bot.choice = "papel";
                else if(Computer() == 2)
                    bot.choice = "gunting";
                else
                    bot.choice = "bato";

            //calls the method with a logic in the hierarchy of choices and return a number for a score
                int result = Compare(bot.choice, player1.choice.toLowerCase());
                    if(result == 1){
                        player1.score++;
                        System.out.printf("YOU WIN!\n%s: %s \nBot: %s \n%s %d | Bot %d\n", player1.name, player1.choice, bot.choice, player1.name, player1.score, bot.score);
                    }
                    else if(result == 2){
                        bot.score++;
                        System.out.printf("COMPUTER WIN\n%s: %s \nBot: %s \n%s %d | Bot %d\n", player1.name, player1.choice, bot.choice, player1.name, player1.score, bot.score);
                    }
                    else if(result == 0){
                        //draw no scores
                        System.out.printf("DRAW\n%s: %s \nBot: %s \n%s %d | Bot %d\n", player1.name, player1.choice, bot.choice, player1.name, player1.score, bot.score);
                    }

        }

        //compares the both scores and displays the winner from 3 rounds
            if(player1.score > bot.score)
                System.out.printf("\nYOU WIN THE GAME! \n%s %d | Bot %d", player1.name, player1.score, bot.score);
            else if(player1.score < bot.score)
                System.out.printf("\nCOMPUTER WIN THE GAME \n%s %d | Bot %d", player1.name, player1.score, bot.score);
            else if(player1.score == bot.score)
                System.out.printf("\nITS A DRAW \n%s %d | Bot %d", player1.name, player1.score, bot.score);
    }

    //method that return an integer from 1-3
    public static int Computer(){
        Random random = new Random();
        return random.nextInt(3)+1;
    }
    
    //method that compare choices; returns 1 if human win, 2 if computer win and 0 for draw
    public static int Compare(String bot, String player) {
        if (bot.equals("papel") && player.equals("bato"))
            return 2;
        else if (player.equals("papel") && bot.equals("bato"))
            return 1;
        else if (bot.equals("bato") && player.equals("gunting"))
            return 2;
        else if (player.equals("bato") && bot.equals("gunting"))
            return 1;
        else if (bot.equals("papel") && player.equals("gunting"))
            return 1;
        else if (player.equals("papel") && bot.equals("gunting"))
            return 2;
        else if (player.equals(bot))
            return 0;
        else
            return -1; 
    }
}



