import java.util.Random;
import java.util.Scanner;

class RPSGame {
    private static final String[] CHOICES = {"Papel", "Gunting", "Bato"};

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();
        int userScore = 0;
        int botScore = 0;
        int rounds = 5;  // You can adjust the number of rounds as per your preference

        System.out.println("Welcome to Papel, Gunting, Bato Game!");

        for (int round = 1; round <= rounds; round++) {
            System.out.println("\nRound " + round);
            System.out.print("Enter your choice (Papel, Gunting, Bato): ");
            String userChoice = scanner.nextLine().toLowerCase();

            // Validate user input
            while (!isValidChoice(userChoice)) {
                System.out.println("Invalid choice! Please enter Papel, Gunting, or Bato.");
                userChoice = scanner.nextLine().toLowerCase();
            }

            // Generate bot's choice
            String botChoice = getRandomChoice(random);

            // Determine the winner for the round
            String result = determineWinner(userChoice, botChoice);
            System.out.println("Bot chose: " + botChoice);
            System.out.println(result);

            // Update scores
            if (result.equals("You win!")) {
                userScore++;
            } else if (result.equals("Bot wins!")) {
                botScore++;
            }
        }

        // Print final scores
        System.out.println("\nGame Over! Final Scores:");
        System.out.println("You: " + userScore + " Bot: " + botScore);

        // Close the scanner
        scanner.close();
    }

    private static boolean isValidChoice(String choice) {
        return choice.equals("papel") || choice.equals("gunting") || choice.equals("bato");
    }

    private static String getRandomChoice(Random random) {
        int index = random.nextInt(CHOICES.length);
        return CHOICES[index];
    }

    private static String determineWinner(String userChoice, String botChoice) {
        if (userChoice.equals(botChoice)) {
            return "It's a tie!";
        } else if ((userChoice.equals("papel") && botChoice.equals("Gunting"))
                || (userChoice.equals("gunting") && botChoice.equals("Bato"))
                || (userChoice.equals("bato") && botChoice.equals("Papel"))) {
            return "Bot wins!";
        } else {
            return "You win!";
        }
    }
}