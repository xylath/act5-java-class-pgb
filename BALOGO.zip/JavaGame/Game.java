import java.util.Scanner;

public class Game {
    private int userScore;
    private int botScore;
    private int rounds = 3;

    public void startGame(Player player) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to Papel, Gunting, Bato Game!");

        for (int round = 1; round <= rounds; ) {
            System.out.println("\nRound " + round);
            String userChoice = player.getUserChoice(scanner);

            String botChoice = Bot.getRandomChoice();
            System.out.println("Bot picked: " + botChoice);

            String result = determineWinner(userChoice, botChoice);
            System.out.println(result);

            if (result.equals("You win!")) {
                userScore++;
                round++;
            } else if (result.equals("Bot wins!")) {
                botScore++;
                round++;
            }
        }

        displayFinalResults();
        scanner.close();
    }

    private String determineWinner(String userChoice, String botChoice) {
        if (userChoice.equals(botChoice)) {
            return "It's a draw! Try again.";
        } else if ((userChoice.equals("papel") && botChoice.equals("gunting")) ||
                (userChoice.equals("gunting") && botChoice.equals("bato")) ||
                (userChoice.equals("bato") && botChoice.equals("papel"))) {
            return "Bot wins!";
        } else {
            return "You win!";
        }
    }

    private void displayFinalResults() {
        System.out.println("\nGame Over!");
        System.out.println("Your score: " + userScore);
        System.out.println("Bot's score: " + botScore);

        if (userScore > botScore) {
            System.out.println("You are the winner!");
        } else if (userScore < botScore) {
            System.out.println("Bot is the winner!");
        } else {
            System.out.println("It's a draw!");
        }
    }
}
