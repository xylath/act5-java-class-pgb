import java.util.Scanner;

public class Player {

    public String getUserChoice(Scanner scanner) {
        System.out.print("Papel, Gunting, Bato! What's your pick? ");
        String userChoice = scanner.nextLine().toLowerCase();

        while (!(userChoice.equals("papel") || userChoice.equals("gunting") || userChoice.equals("bato"))) {
            System.out.println("Invalid choice. Please enter Papel, Gunting, or Bato.");
            System.out.print("Papel, Gunting, Bato! What's your pick? ");
            userChoice = scanner.nextLine().toLowerCase();
        }

        return userChoice;
    }
}
