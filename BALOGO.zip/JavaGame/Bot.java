import java.util.Random;

public class Bot {

    public static String getRandomChoice() {
        String[] choices = {"Papel", "Gunting", "Bato"};
        int randomIndex = new Random().nextInt(choices.length);
        return choices[randomIndex].toLowerCase();
    }
}
