public class PapelGuntingBatoGame {

    public static void main(String[] args) {
        Game game = new Game();
        Player player = new Player();
        game.startGame(player);
    }
}

