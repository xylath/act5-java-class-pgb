import java.util.Scanner;
import Main_classes.players;

public class Main {
    //create player objects
    static players you = new players();
    static players enemy = new players();
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("PAPEL-GUNTING-BATO!\n(best of 10)");
        System.out.print("Write your name: ");
        you.name = scanner.nextLine();
        System.out.print("\nWrite your adversary's name: ");
        enemy.name = scanner.nextLine();
        System.out.print("\n\n\n\n\n\n\n\n\n\n");
        
        while (!(enemy.Score == 10 || you.Score == 10))
        {
            //players make their choices, method is dependent on the function used
            String action1 = you.choice_inputtype();
            String action2 = enemy.choice_rngtype();
            //print players' choices
            System.out.printf("%s's fingers were shaped like a [%s]\n",you.name , action1);
            System.out.printf("%s's virtual fingers were shaped like a [%s]\n\n",enemy.name , action2);
            //papel-gunting-bato algorithm, will win if player1 has winning hand vs player 2, lose otherwise, and tie if the same fingers
            if (action1.equals(action2)) {
                System.out.println("It's a tie!");
            } else if ((action1.equals("bato") && action2.equals("gunting")) ||
                    (action1.equals("papel") && action2.equals("bato")) ||
                    (action1.equals("gunting") && action2.equals("papel"))) {
                System.out.println("You win!");
                you.Score++;
            } else {
                System.out.println("You lost!");
                enemy.Score++;
            }
            //print players' scores
            System.out.printf("\n%s's score: %d\n", you.name, you.Score);
            System.out.printf("%s's score: %d\n\n", enemy.name, enemy.Score);
        }
        if (you.Score > enemy.Score) {
            System.out.printf("Woah! %s is da Papel-Gunting-Bato Champion!!!\n", you.name);
        } else if (enemy.Score > you.Score) {
            System.out.printf("Woah! %s is da Papel-Gunting-Bato Champion!!!\n", enemy.name);
        } /*else {
            null for now
        }*/
        System.out.print("\n\n\n\n");
        scanner.close();
    }
}