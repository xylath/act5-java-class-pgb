package Main_classes;
import java.util.Scanner;
public class players {
    Scanner scanner = new Scanner(System.in);
    //array which a random number generator can access to pick from
    String moves[] = {"bato", "papel", "gunting"};
    //variables:(top to bottom) >>the move to be done in String type >>players' names >>players' scores
    public String choice;
    public String name;
    public int Score;

    //function that gets the user's input
    public String choice_inputtype() {
        System.out.print("Papel, Gunting, Bato! What's your Pick?: ");
        choice = scanner.nextLine();
        //modifies the received input into all lowercase Strings
        choice = choice.toLowerCase();
        //returns error message and reiterates the whole function again in case user input is beyond scope
        if (!((choice.equals("bato")) || (choice.equals("gunting")) || (choice.equals("papel")))) {
            System.out.println("Woah! Wrong input!");
            choice_inputtype();
        }
        return choice;
    }
    //random choice generator, returns String
    public String choice_rngtype() {
        int random = (int)(Math.random() * moves.length);
        return choice = moves[random];
    }
}