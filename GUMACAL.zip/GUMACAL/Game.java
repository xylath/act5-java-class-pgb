public class Game {
    private int userScore;
    private int computerScore;

    public String play(String userChoice) {
        // Generate a random choice for the computer
        String[] choices = {"Rock", "Paper", "Scissors"};
        String computerChoice = choices[(int) (Math.random() * choices.length)];

// Display user and computer choices
        System.out.println("Your choice: " + userChoice);
        System.out.println("Computer's choice: " + computerChoice);

// Determine the winner
        if (userChoice.equalsIgnoreCase(computerChoice)) {
            return "It's a tie!";
        } else if (
            (userChoice.equalsIgnoreCase("Rock") && computerChoice.equalsIgnoreCase("Scissors")) ||
            (userChoice.equalsIgnoreCase("Paper") && computerChoice.equalsIgnoreCase("Rock")) ||
            (userChoice.equalsIgnoreCase("Scissors") && computerChoice.equalsIgnoreCase("Paper"))
        ) {
            userScore++;
            return "You win!";
        } else {
            computerScore++;
            return "Computer wins!";
        }
    }

    public String getStandings() {
        return "Standings: You - " + userScore + ", Computer - " + computerScore;
    }
}
