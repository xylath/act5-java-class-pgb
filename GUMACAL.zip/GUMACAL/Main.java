//NOTE!
//To run the program use the terminal
//In the terminal you need to input "javac Main.java Game.java" press enter and then input "java Main"

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Rock, Paper, Scissors Game!");

// Get the number of rounds
		System.out.print("Enter the number of rounds: ");
		int numberOfRounds = scanner.nextInt();
		scanner.nextLine(); // Consume the newline character

// Create an instance of the Game class
		Game game = new Game();

// Play multiple rounds
		for (int round = 1; round <= numberOfRounds; round++) {
			System.out.println("\nRound " + round);

// Get user choice
			System.out.print("Enter your choice (Rock, Paper, or Scissors): ");
			String userChoice = scanner.nextLine().toLowerCase();

// Play the round and display the result
			String result = game.play(userChoice);
			System.out.println(result);
		}

// Display standings at the end of all rounds
		System.out.println("\nGame Over!");
		System.out.println(game.getStandings());

// Close the scanner
		scanner.close();
	}
}
