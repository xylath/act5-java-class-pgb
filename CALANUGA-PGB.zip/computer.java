import java.util.Random;

// Internal class representing the game logic
class PapelGuntingBatoGame {
    private String userChoice;
    private String computerChoice;
    private int userScore;
    private int computerScore;

    // Constructor
    public PapelGuntingBatoGame(String userChoice) {
        this.userChoice = userChoice;
        generateComputerChoice();
        playRound();
    }

    // Internal method to generate computer's choice
    private void generateComputerChoice() {
        Random random = new Random();
        int randomChoice = random.nextInt(3);

        switch (randomChoice) {
            case 0:
                this.computerChoice = "Papel";
                break;
            case 1:
                this.computerChoice = "Gunting";
                break;
            case 2:
                this.computerChoice = "Bato";
                break;
        }
    }

    // Internal method to play a round
    private void playRound() {
        System.out.println("Computer chose: " + computerChoice);

        if (userChoice.equalsIgnoreCase(computerChoice)) {
            System.out.println("It's a draw!");
        } else if ((userChoice.equalsIgnoreCase("Papel") && computerChoice.equalsIgnoreCase("Bato"))
                || (userChoice.equalsIgnoreCase("Gunting") && computerChoice.equalsIgnoreCase("Papel"))
                || (userChoice.equalsIgnoreCase("Bato") && computerChoice.equalsIgnoreCase("Gunting"))) {
            System.out.println("You win this round!");
            userScore++;
        } else {
            System.out.println("Computer wins this round!");
            computerScore++;
        }
    }

    // Internal method to get user's score for the round
    public int getUserScore() {
        return userScore;
    }

    // Internal method to get computer's score for the round
    public int getComputerScore() {
        return computerScore;
    }
}

