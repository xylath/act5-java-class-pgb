import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to Papel, Gunting, Bato!");

        int userTotalScore = 0;
        int computerTotalScore = 0;
        int totalRounds = 3;// Adjust the Round of the Game

        for (int round = 1; round <= totalRounds; round++) {
            System.out.println("\nRound " + round);
            System.out.println("Papel, Gunting, or Bato! What's your Pick");
            String userChoice = scanner.nextLine();

            PapelGuntingBatoGame game = new PapelGuntingBatoGame(userChoice);

            // Get the scores for each round
            int userRoundScore = game.getUserScore();
            int computerRoundScore = game.getComputerScore();

            // Accumulate scores for total score
            userTotalScore += userRoundScore;
            computerTotalScore += computerRoundScore;

            System.out.println("You: " + userRoundScore + " | Computer: " + computerRoundScore);
            System.out.print("\n------------------------------------------------------------\n");

        }

        System.out.println("\nEnd of the Game!");
        System.out.println("Final Score - You: " + userTotalScore + " | Computer: " + computerTotalScore);

        scanner.close();
    }
}
