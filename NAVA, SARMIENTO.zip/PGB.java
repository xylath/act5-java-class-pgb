import game.*;

import java.util.Scanner;

public class PGB {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Bot robot = new Bot();
        Player player = new Player();

        for (int round = 1; round <= 3; round++) {
            System.out.println("\nRound " + round);
            System.out.println("Papel, Gunting, Bato! What's your Pick?");

            robot.getRobotChoice();
            player.getPlayerChoice(scanner);
            System.out.println("Robot's Choice: " + robot.choice);

            getScore(player, robot);
            viewScore(player, robot);
        }

        getStats(player, robot);

    }

    public static void viewScore(Player player, Bot robot){
        System.out.println("\nYour Score: " + player.score + "\nBot's Score: " + robot.score);
    }

    public static void getScore(Player player, Bot robot) {
        String result;
        
        if (player.choice.equals(robot.choice)) {
            result = "\nIt's a tie!";
        } else if ((player.choice.equals("Bato") && robot.choice.equals("Gunting")) ||
                   (player.choice.equals("Papel") && robot.choice.equals("Bato")) ||
                   (player.choice.equals("Gunting") && robot.choice.equals("Papel"))) {
            result = "\nCongratulations! Player Wins This Round!";
            player.score++;
        } else {
            result = "\nYou lost this round. Try again next time. Bot Wins This Round!";
            robot.score++;
        }
        
        System.out.println(result);
    }
    

    public static void getStats(Player player, Bot robot){
        double playerWinrate = player.score / 3.0 * 100;
        double robotWinrate = robot.score / 3.0 * 100;
        System.out.println("\nGAMEPLAY STATISTICS");
        System.out.printf("Your Overall Score: %d / 3\n", player.score);
        System.out.printf("Bot Overall Score: %d / 3\n", robot.score);
        System.out.printf("Your Win Rate: %.2f%%\n", playerWinrate);
        System.out.printf("Bot Win Rate: %.2f%%\n", robotWinrate);
    
        if (player.score > robot.score){
            System.out.println("\nCongratulations on your one-on-one win!");
        }
        else if (player.score == robot.score) {
            System.out.println("\nIt's a tie!");
        }
        else{
            System.out.println("\nThere's no way to go but up. Try again!");
        }
    }
    
}
    
