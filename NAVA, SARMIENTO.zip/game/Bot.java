package game;

import java.util.Random;

public class Bot {
    public int score = 0;
    public String choice;

    public String getRobotChoice(){
        final String[] GUESSES = {"Bato", "Papel", "Gunting"};

        Random random = new Random();
        int rand = random.nextInt(3);

        choice = GUESSES[rand];
        return choice;
    }



}
