package Players; //This class belongs to the Players package

import java.util.Random;

public class Robot {
    private String choice;

    public void choose() {
        String[] choices = {"papel", "gunting", "bato"};
        choice = choices[new Random().nextInt(choices.length)];
    }

    public String getChoice() {
        return choice;
    }
}
