package Players; //This class belongs to the Players package

import java.util.Scanner;

public class Player {
    private String choice;

    public void choose() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.print("Ilagay ang iyong napili (papel, gunting, bato): ");
            String playerInput = scanner.nextLine().toLowerCase();

            // Check if the player's input is a valid choice
            if (playerInput.equals("papel") || playerInput.equals("gunting") || playerInput.equals("bato")) {
                choice = playerInput;
                break; // Exit the loop if the input is valid
            } else {
                System.out.println("Error: Pumili lamang sa papel, gunting, bato.");
            }
        }
    }

    public String getChoice() {
        return choice;
    }
}
