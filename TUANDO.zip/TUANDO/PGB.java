import Players.*; //Imports classes found in Players package

import java.util.Scanner;

public class PGB{

    public static void main(String[] args) {
        // Welcome message for the player
        System.out.println("\nPAPEL, GUNTING, BATO! Ano ang sa'yo?");
        System.out.println("Ikaw ay naglalaro ng Papel, Gunting, Bato na nasa pinakabagong edisyon!");

        // Initializing scores to 0
        int playerScore = 0;
        int robotScore = 0;

        // Loop for the game
        while (true) {
            // Informing user of a new round
            System.out.println("\nMag-uumpisa na ang bagong round...");

            Player player = new Player();
            Robot robot = new Robot();

            player.choose();
            robot.choose();

            System.out.println("Ang pinili mo: " + player.getChoice());
            System.out.println("Ang pinili ng Robot: " + robot.getChoice());

            // Determine the winner for the round
            String result = RoundWinner(player.getChoice(), robot.getChoice());
            System.out.println(result);

            // Update scores of players
            if (result.equals("Ikaw ang nanalo!")) {
                playerScore++;
            } else if (result.equals("Ang Robot ang nanalo!")) {
                robotScore++;
            }

            // Display current scores of players
            System.out.println("Score - Player: " + playerScore + " | Robot: " + robotScore);

            // Check if at least 3 rounds have been played
            if (playerScore >= 3 || robotScore >= 3) {
                // Check if who is leading
                if (playerScore > robotScore) {
                    System.out.println("Ikaw ay nangunguna!");
                } else if (robotScore > playerScore) {
                    System.out.println("Ang robot ang nangunguna!");
                } else {
                    System.out.println("Tie kayo! Mag-uumpisa ang panibagong round para sa tie-breaker.");
                }

                // Ask if the player wants to play another round
                System.out.print("Gusto mo pa bang maglaro? (oo/hindi): ");
                Scanner scanner = new Scanner(System.in);
                String playAgain = scanner.nextLine().toLowerCase();

                // Check if the player wants to play another round
                if (!playAgain.equals("oo")) {
                    break; // Exit the game loop
                }
            }
        }

        // Game over message
        System.out.println("Tapos na ang laro. Salamat!");
    }

    private static String RoundWinner(String playerChoice, String robotChoice) {
        // Determine the winner of the round
        if (playerChoice.equals(robotChoice)) {
            return "Tie kayo!";
        } else if (
                        (playerChoice.equals("bato") && robotChoice.equals("gunting")) ||
                        (playerChoice.equals("papel") && robotChoice.equals("bato")) ||
                        (playerChoice.equals("gunting") && robotChoice.equals("papel"))
        ) {
            return "Ikaw ang nanalo!";
        } else {
            return "Ang Robot ang nanalo!";
        }
    }
}
