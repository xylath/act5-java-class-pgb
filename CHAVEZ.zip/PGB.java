import play.*; // imported both Player and Robot class

import java.util.Scanner;

public class PGB {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int rounds; // user's chosen number of rounds 
        int userScore = 0; // score of the user
        int botScore = 0; // score of the bot

        System.out.print("Enter the number of rounds: ");
        rounds = scanner.nextInt();

        Player user = new Player("");
        Robot bot = new Robot();

        for (int i = 1; i <= rounds; i++) {
            System.out.println("\nRound " + i);
            System.out.print("Welcome to Pinoy's Papel, Gunting, Bato! What's your pick? ");
            user.setChoice(scanner.next().toLowerCase()); // Convert to lowercase for case-insensitive comparison

            String botChoice = bot.makeChoice();
            System.out.println("Bot picks: " + botChoice);

            String result = determineWinner(user.getChoice(), botChoice);

            if (result.equals("user")) {
                System.out.println("You win this round!"); // condition if the user won
                userScore++;
            } else if (result.equals("bot")) {
                System.out.println("Bot wins this round!"); // condition if the bot won
                botScore++;
            } else {
                System.out.println("It's a tie!"); // condtion if it's a tie otherwise
            }
        }

        System.out.println("\nGame over!");
        System.out.println("Your score: " + userScore);
        System.out.println("Bot's score: " + botScore);

        if (userScore > botScore) {
            System.out.println("You win the game!");
        } else if (botScore > userScore) {
            System.out.println("Bot wins the game!");
        } else {
            System.out.println("The game is a tie!");
        }

        scanner.close();
    }

    private static String determineWinner(String userChoice, String botChoice) {
        if (userChoice.equals(botChoice)) {
            return "tie";
        } else if (
                (userChoice.equals("papel") && botChoice.equals("gunting")) ||
                (userChoice.equals("gunting") && botChoice.equals("bato")) ||
                (userChoice.equals("bato") && botChoice.equals("papel"))
        ) {
            return "bot";
        } else {
            return "user";
        }
    }
}