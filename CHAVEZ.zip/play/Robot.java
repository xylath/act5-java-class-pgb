package play; // Robot class - to be imported to the PGB class


import java.util.Random; // import and declare random choices for bot

public class Robot {
    private Random random;
    private String[] choices;

    public Robot() {
        random = new Random();
        choices = new String[]{"papel", "gunting", "bato"}; // bot's choices
    }

    public String makeChoice() {
        return choices[random.nextInt(choices.length)];
    }
}