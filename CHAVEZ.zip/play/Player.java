package play; // Player class - to be imported to the PGB class


public class Player {
    private String choice;

    public Player(String choice) {
        this.choice = choice;
    }

    public String getChoice() {
        return choice;
    }

    public void setChoice(String choice) {
        this.choice = choice;
    }
}