// Declaring the package 'game'
package game;

import java.util.Scanner;

// Player class for handling user input
public class Player {

    // Method to get the player's choice
    public String makeChoice() {
        
        // Creating a Scanner object for user input
        Scanner playerChoice = new Scanner(System.in);

        // Prompting the user to enter their choice
        System.out.print("Encode your choice: (rock/paper/scissors): ");
        
        // Reading the user's input and converting it to lowercase
        return playerChoice.nextLine().toLowerCase();
    }
}
