// Declaring the package 'game'
package game;

import java.util.Random;

// Bot class for generating a random choice for the bot
public class Bot {

    // Method to generate a random choice for the bot
    public String makeChoice() {
        
        // Array of possible choices for the bot
        String[] botChoice = {"rock", "paper", "scissors"};

        // Creating a Random object to generate a random index
        Random random = new Random();

        // Generating a random index to select a choice from the array
        int index = random.nextInt(botChoice.length);

        // Printing the bot's choice to the console
        System.out.println("\n\nBOT CHOSE: " + botChoice[index]);

        // Returning the selected choice
        return botChoice[index];
    }
}
