// Importing all classes in the 'game' package
import game.*;

public class Main {

    //initializing variables
    private int playerScore;
    private int botScore;

     // Main method to start the game
    public static void main(String[] args) {
        // Create instances of the game, player, and bot
        Main game = new Main();
        Player player = new Player();
        Bot bot = new Bot();

        // Start playing the game
        game.playRound(player, bot);
    }

    // Method to play a round of the game
    public void playRound(Player player, Bot bot) {
        System.out.println("\n\n   Welcome to Rock, Paper, Scissors Game!");

        for (int round = 1; round <= 3; round++) {
            System.out.println("++++++++++++++++++++++++++++++++++++++++++++");
            System.out.println("\t\t ROUND " + round);
            System.out.println("++++++++++++++++++++++++++++++++++++++++++++");

            // Get choices from player and bot
            String playerChoice = player.makeChoice();
            String botChoice = bot.makeChoice();

            // Determine the winner of the round
            if (playerChoice.equals(botChoice)) {
                System.out.println("====================================");
                System.out.println("\t\tIt's a tie!");
                System.out.println("====================================");
            } else if ((playerChoice.equals("rock") && botChoice.equals("scissors")) ||
                    (playerChoice.equals("paper") && botChoice.equals("rock")) ||
                    (playerChoice.equals("scissors") && botChoice.equals("paper"))) {
                System.out.println("====================================");
                System.out.println("Congratulations, You took the win!");
                System.out.println("====================================");
                playerScore++;
            } else {
                System.out.println("====================================");
                System.out.println("Unfortunately, the bot wins!");
                System.out.println("====================================");
                botScore++;
            }

            // Print scores after each round
            printScores();
        }
    }

    // Method to print the current scores
    private void printScores() {
        System.out.println("\nScore: You " + playerScore + " - " + botScore + " Bot\n");
        System.out.println();
    }
}
