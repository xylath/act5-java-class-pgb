// Player.java
public class Player {
    private String choice;

    public Player(String choice) {
        this.choice = choice;
    }

    public String getChoice() {
        return choice;
    }
}
