// Game.java
import java.util.Random;
import java.util.Scanner;

public class Game {
    private static final String[] CHOICES = {"Bato", "Papel", "Gunting"};
    private static final int ROUNDS = 3;

    private int userScore = 0;
    private int botScore = 0;

    public void playGame() {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        for (int round = 1; round <= ROUNDS; round++) {
            System.out.println("Round " + round);

            Player user = getUserInput(scanner);
            Player bot = getBotChoice(random);

            System.out.println("Bot picked: " + bot.getChoice());

            determineWinner(user, bot);
        }

        printFinalScore();
        scanner.close();
    }

    private Player getUserInput(Scanner scanner) {
        System.out.print("Bato, Papel, Gunting. What's your pick? ");
        String userChoice = scanner.nextLine().toLowerCase();

        while (!isValidChoice(userChoice)) {
            System.out.println("Invalid choice. Please enter Bato, Papel, or Gunting.");
            System.out.print("Bato, Papel, Gunting. What's your pick? ");
            userChoice = scanner.nextLine().toLowerCase();
        }

        return new Player(userChoice);
    }

    private Player getBotChoice(Random random) {
        String botChoice = CHOICES[random.nextInt(CHOICES.length)];
        return new Player(botChoice);
    }

    private boolean isValidChoice(String choice) {
        for (String validChoice : CHOICES) {
            if (validChoice.toLowerCase().equals(choice)) {
                return true;
            }
        }
        return false;
    }

    private void determineWinner(Player user, Player bot) {
        if (user.getChoice().equals(bot.getChoice())) {
            System.out.println("It's a tie!");
        } else if ((user.getChoice().equals("bato") && bot.getChoice().equals("Gunting")) ||
                   (user.getChoice().equals("papel") && bot.getChoice().equals("Bato")) ||
                   (user.getChoice().equals("gunting") && bot.getChoice().equals("Papel"))) {
            System.out.println("You win this round!");
            userScore++;
        } else {
            System.out.println("Bot wins this round!");
            botScore++;
        }
    }

    private void printFinalScore() {
        System.out.println("\nGame Over!");
        System.out.println("Your Score: " + userScore);
        System.out.println("Bot Score: " + botScore);

        if (userScore > botScore) {
            System.out.println("Congratulations! You win!");
        } else if (userScore < botScore) {
            System.out.println("Sorry, you lose. Better luck next time!");
        } else {
            System.out.println("It's a tie!");
        }
    }
}
