/* 
    Submitted by:
        John Manuel Carado
        Jephone Torre
        --- BSCS 2-A AI ---
*/

import BBPCLASS.*;

public class pgb {
    public static void main(String[] args) {
        BatoBatoPickGame Robot = new BatoBatoPickGame();
        Robot.setTotalScore(5); // Default score = 3
        Robot.playGame();
    }
}
