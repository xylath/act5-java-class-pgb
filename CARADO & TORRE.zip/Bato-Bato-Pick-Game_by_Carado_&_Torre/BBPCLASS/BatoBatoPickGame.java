package BBPCLASS;

import java.util.Scanner;
import java.util.Random;

public class BatoBatoPickGame {

    private int robotScore;
    private String robotChoice;
    private int totalScore = 3;
    private String[] choices = { "Gunting", "Papel", "Bato" };

    private void displayScore(int playerScore) {
        System.out.println("Bot: " + robotScore + ", You: " + playerScore);
    }

    private String[] getChoices() {
        return choices;
    }

    private void getWinner(int myScore) {
        System.out.println();
        displayScore(myScore);
        if (myScore > robotScore) {
            System.out.println("You win by " + (myScore - robotScore) + " more points than the bot!");
        } else if (myScore < robotScore) {
            System.out.println("You lose by " + (robotScore - myScore) + " less points than the bot!");
        } else {
            System.out.println("It's a tie!");
        }
    }

    public void setTotalScore(int score) {
        totalScore = score;
    }

    private boolean isValidChoice(String choice) {
        for (String validChoice : choices) {
            if (validChoice.toLowerCase().equals(choice)) {
                return true;
            }
        }
        return false;
    }

    public void playGame() {
        Random random = new Random();
        Scanner inputStr = new Scanner(System.in);
        int myScore = 0;
        int currentRound = 1;

        while (myScore < totalScore && robotScore < totalScore) {
            System.out.println("\nRound " + currentRound + ": \nPapel, Gunting, Bato! What's your pick?");
            System.out.print("Input: ");
            String choice;

            do {
                choice = inputStr.nextLine().toLowerCase();
                if (!isValidChoice(choice)) {
                    System.out.println("\nInvalid Input. Please enter Bato, Papel, or Gunting.");
                    System.out.print("Input: ");
                }
            } while (!isValidChoice(choice));

            int randomIndex = random.nextInt(getChoices().length);
            robotChoice = choices[randomIndex];

            System.out.println("Robot: " + robotChoice);
            robotChoice = robotChoice.toLowerCase();

            if (choice.equals(robotChoice)) {
                System.out.print("Tie! ");
                displayScore(myScore);
                currentRound++;
                continue;
            }

            switch (choice) {
                case "bato":
                    if (robotChoice.equals("gunting")) {
                        myScore++;
                        System.out.print("You win! ");
                    } else if (robotChoice.equals("papel")) {
                        robotScore++;
                        System.out.print("You lose! ");
                    }
                    break;
                case "papel":

                    if (robotChoice.equals("bato")) {
                        myScore++;
                        System.out.print("You win! ");
                    } else if (robotChoice.equals("gunting")) {
                        robotScore++;
                        System.out.print("You lose! ");
                    }
                    break;

                case "gunting":
                    if (robotChoice.equals("papel")) {
                        myScore++;
                        System.out.print("You win! ");
                    } else if (robotChoice.equals("bato")) {
                        robotScore++;
                        System.out.print("You lose! ");
                    }
                    break;

                default:
                    System.out.println("Invalid Input. Repeating Game");
                    break;
            }
            displayScore(myScore);
            currentRound++;
        }
        inputStr.close();
        getWinner(myScore);
    }
}