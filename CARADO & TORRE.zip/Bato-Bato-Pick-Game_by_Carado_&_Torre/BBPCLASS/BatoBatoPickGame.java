package BBPCLASS;

import java.util.Scanner;
import java.util.Random;

public class BatoBatoPickGame {

    private int robotScore;
    private String robotChoice;
    private int totalScore = 3;
    private String[] choices = { "Gunting", "Papel", "Bato" };

    private void displayScore(int playerScore) {
        System.out.println("Bot: " + robotScore + ", You: " + playerScore);
    }

    private String[] getChoices() {
        return choices;
    }

    private void getWinner(int myScore) {

        System.out.println("\nYou: " + myScore + ", Bot: " + robotScore);

        if (myScore > robotScore) {
            System.out.println("You win by " + (myScore - robotScore) + " more points than the bot!");
        } else if (myScore < robotScore) {
            System.out.println("You lose by " + (robotScore - myScore) + " less points than the bot!");
        } else {
            System.out.println("It's a tie! Final score: Bot: " + robotScore + ", You: " + myScore);
        }
    }

    public void setTotalScore(int score) {
        totalScore = score;
    }

    private boolean isValidChoice(String choice) {
        for (String validChoice : choices) {
            if (validChoice.toLowerCase().equals(choice)) {
                return true;
            }
        }
        return false;
    }

    public void playGame() {
        Random random = new Random();
        Scanner inputStr = new Scanner(System.in);
        int myScore = 0;
        int currentRound = 1;

        while (myScore < totalScore && robotScore < totalScore) {
            System.out.println("\nRound " + currentRound + ": \nPapel, Gunting, Bato! What's your pick?");
            System.out.print("Input: ");
            String choice;

            do {
                choice = inputStr.nextLine().toLowerCase();
                if (!isValidChoice(choice)) {
                    System.out.println("\nInvalid Input. Please enter Bato, Papel, or Gunting.");
                    System.out.print("Input: ");
                }
            } while (!isValidChoice(choice));

            int randomIndex = random.nextInt(getChoices().length);
            robotChoice = choices[randomIndex];

            System.out.println("Robot: " + robotChoice);

            switch (choice) {
                case "bato":
                case "papel":
                case "gunting":
                    if (choice.equals(robotChoice.toLowerCase())) {
                        System.out.print("Tie! ");
                    } else if ((choice.equals("bato") && robotChoice.equals("gunting")) ||
                            (choice.equals("papel") && robotChoice.equals("bato")) ||
                            (choice.equals("gunting") && robotChoice.equals("papel"))) {
                        myScore++;
                        System.out.print("You win! ");
                    } else {
                        robotScore++;
                        System.out.print("You lose! ");
                    }
                    break;

                default:
                    System.out.println("Invalid Input. Repeating Game");
                    break;
            }
            displayScore(myScore);
            currentRound++;
        }
        inputStr.close();
        getWinner(myScore);
    }
}