package Players;

import java.util.Scanner;

public class Player {
    public int score = 0;

    public String name;

    public String choice;

    //possible choices of the player
    final private String[] CHOICES = {"Bato", "bato", "BATO", "Papel", "papel", "PAPEL", "Gunting", "gunting", "GUNTING"};

    public String getPlayerChoice(Scanner scanner){
        System.out.print("\nYour Choice: ");

        do{
        choice = scanner.next();
        //formatting the input of the human player
        if (choice.equals(CHOICES[0]) || choice.equals(CHOICES[1]) || choice.equals(CHOICES[2]) ){
            choice = "Bato";
            return choice;
        }

        else if (choice.equals(CHOICES[3]) || choice.equals(CHOICES[4]) || choice.equals(CHOICES[5]) ){
            choice = "Papel";
            return choice;
        }

        else if (choice.equals(CHOICES[6]) || choice.equals(CHOICES[7]) || choice.equals(CHOICES[8]) ){
            choice = "Gunting";
           return choice;
        }

        else{
            System.out.println("Error! Please try again");
        }
        }while (true);

    }
}
