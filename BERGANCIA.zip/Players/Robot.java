package Players;

import java.util.Random;

//code for random guessing of robot
public class Robot {
    public int score = 0;
    public String choice;

    //returns the choice of the robot
    public String getRobotChoice(){
        //list of all possible guesses
        final String[] GUESSES = {"Bato", "Papel", "Gunting"};

        Random random = new Random();
        int rand = random.nextInt(3);

        choice = GUESSES[rand];
        return choice;
    }



}
