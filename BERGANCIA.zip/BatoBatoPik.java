//this program allows the user to play the game 'bato-bato-pick' with a bot who uses randomized guesses
//in another class. It uses the concept of external classes to properly format/sort code
//Made by Mauricio Manuel F. Bergancia -> BSCS 2-A AI

import Players.*;

import java.text.DecimalFormat;
import java.util.Scanner;

public class BatoBatoPik {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Robot robot = new Robot();
        Player player = new Player();

        //greet the user
        greetings(player, scanner);

        //Play for 3 rounds
        for (int round = 1; round <= 3; round++) {
            System.out.println("\n=============================================================");
            System.out.println("\t\t\t\t\t\tRound " + round);
            System.out.println("Papel, Gunting, Bato! What's your Pick?");

            //get each player's choice
            robot.getRobotChoice();
            player.getPlayerChoice(scanner);
            System.out.println("Players.Robot's Choice: " + robot.choice);

            //get and view the score of each player
            getScore(player, robot);
            viewScore(player, robot);
        }
        System.out.println("\n=============================================================");

        //show the statistics of each player
        getStats(player, robot);

    }

    public static void greetings(Player player, Scanner scanner) {
        System.out.print("\nInput Name: ");
        player.name = scanner.nextLine();
        System.out.printf("\nHello there %s!", player.name );

        System.out.println("\n\nWelcome to Bato-Bato-Pick! This is a popular game in the Philippines, also known as ‘Rock\nPaper Scissors’ in other parts of the world. It’s a simple yet exciting game of chance and strategy, where two \nplayers simultaneously form one of three shapes with their hand: a rock (bato), paper (papel), or scissors (gunting).");

        System.out.println("\nThe winner is determined by the rules of the game: Rock crushes scissors, scissors cuts paper, and\npaper covers rock. It’s a fun and quick game that tests your luck and your ability to outwit your opponent.\nSo, get ready to play ‘Bato-Bato-Pick’ and may the best hand win!");

        System.out.println("\nYou will be challenging our futuristic and complex AI system! We wish you the best of luck!");
    }

    public static void viewScore(Player player, Robot robot){
        System.out.println("\nYour Score: " + player.score + "                            Players.Robot's Score: " + robot.score);
    }

    public static void getScore(Player player, Robot robot) {

        switch (robot.choice) {

            case "Bato":
                switch (player.choice) {

                    case "Bato" -> {
                        System.out.println("\nIt's a tie!");
                    }

                    case "Papel" -> {
                        System.out.println("\nCongratulations! Human Players.Player Wins This Round!");
                        player.score++;
                    }

                    case "Gunting" -> {
                        System.out.println("\nYou lost this round. Try again next time. Players.Robot Wins This Round!");
                        robot.score++;
                    }
                    default -> throw new IllegalStateException("Error! player.choice does not equal any of the choices");
                }

                break;

            case "Papel":
                switch (player.choice) {

                    case "Bato" -> {
                        System.out.println("\nYou lost this round. Try again next time. Players.Robot Players.Player Wins This Round!");
                        robot.score++;
                    }

                    case "Papel" -> {
                        System.out.println("\nIt's a tie!");
                    }

                    case "Gunting" -> {
                        System.out.println("\nCongratulations!  Wins This Round!");
                        player.score++;
                    }

                    default -> throw new IllegalStateException("Error! player.choice does not equal any of the choices");

                }
                break;

            case "Gunting":
                switch (player.choice) {

                    case "Bato" -> {
                        System.out.println("\nCongratulations! Human Players.Player Wins This Round!");
                        player.score++;
                    }

                    case "Papel" -> {
                        System.out.println("\nYou lost this round. Try again next time. Players.Robot Players.Player Wins This Round!");
                        robot.score++;
                    }

                    case "Gunting" -> System.out.println("\nIt's a tie!");

                    default -> throw new IllegalStateException("Error! player.choice does not equal any of the choices");
                }
                break;

            default:
                throw new IllegalStateException("Error! player.choice does not equal any of the choices");
        }


    }

    public static void getStats(Player player, Robot robot){

        //store the win rate of players in double variables
        DecimalFormat df = new DecimalFormat("#.##");
        double playerWinrate = (player.score == 0) ? 0 : (player.score/3.0)*100.00 ;
        double robotWinrate = (robot.score) == 0 ? 0 : (robot.score/3.0)*100.00;

        String playerWr = df.format(playerWinrate);
        String robotWr = df.format((robotWinrate));

        System.out.println("******************************************************");
        System.out.println("\t\t\t\tGAMEPLAY STATISTICS");
        System.out.printf(">> Your Overall Score: %d / 3\n", player.score);
        System.out.printf(">> Players.Robot's Overall Score: %d / 3\n\n", robot.score);

        System.out.printf(">> Your Win Rate: %s%%\n", playerWr);
        System.out.printf(">> Players.Robot's Win Rate: %s%%\n", robotWr);
        System.out.println("******************************************************");

        if (player.score > robot.score){
            System.out.println("\nCongratulations on your one-on-one win against our most complex AI system! You have proven\nthat everything is possible with perseverance and strategic thinking!");
        }
        else if (player.score == robot.score) {
            System.out.println("\nYou have proven that with determination and with proper tactics, you can match anyone's power!");
        }
        else{
            System.out.println("\nYour loss does not mean the end. You did well! Don't let this defeat stop you from achieving your full\npotential!");
        }

    }
}
    
