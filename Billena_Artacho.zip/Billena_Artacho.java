
import Randomizu.BatoPapelGunting;
import java.util.Scanner;
// import java.util.Arrays;

class Billena_Artacho{
    public static void main(String args[]){
        int final_score = 0;
        int bot_score = 0;
        // Number to Move Representation:
        // Positive Represent User
        // 1 = Bato (User)
        // 2 = Papel
        // 3 = Gunting 
       // Negative Represent Bot the bot's possible moves:
        // -1 = Bato 
        // -2 = Papel
        // -3 = Gunting 
        // Custom Randomizer function based on bubble sort and Fisher-Yates Shuffle Algorithm with a Twist from Bubble Sort Sequence
        // A function just to take the user choice and input
        Scanner scannerObj = new Scanner(System.in);
        for(int i = 0;  i < 3; i++){
            System.out.println("Enter your Choice: Bato, Papel, Gunting");
            String user_choice = scannerObj.nextLine();
            int choice = BatoPapelGunting.classiferBPG(user_choice);
            System.out.println("Your choice is: " + user_choice);
            final_score += BatoPapelGunting.generateBPG(choice, final_score, bot_score);
            // Driver Function for Running the Class to generate the actual Bato Papel Gunting Sequence
        }
        BatoPapelGunting.decideWinner(final_score);
        scannerObj.close();
    }
}