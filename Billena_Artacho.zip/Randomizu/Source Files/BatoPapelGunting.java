
package Randomizu;

public class BatoPapelGunting{

    public static int add_score(int final_score){
        return final_score += 1;
    }
    public static int add_score_bot(int bot_score){
        return bot_score += 1;
    }
    // Function used to convert the user's choice into a positive number by taking in the first index of the word as the input and comparing to match the output
    public static int classiferBPG(String user_input){
        String starting_letter_char = user_input.toLowerCase();
        String starting_letter = String.valueOf(starting_letter_char.charAt(0));
        switch (starting_letter) {
            case "b":
                return 1;
            case "p":
                return 2;
            case "g":
                return 3; 
        }
        return 0;
    }
    // Custom driver function that create a probability calculation in a permutation sequence for all of the possible choice between the random bot and user choices
    public static int pointBPG(int bot_choice, int user_choice){
        int probability_calculation = user_choice + bot_choice;
        return probability_calculation; 
    }
    // The actual driver function that generates the resulting numbers
    public static int generateBPG(int user_choice, int final_score, int bot_score){
        // Apply the classifier function first to convert the string into a randomizable function
        // int bot_possible_choices[] = BPG.get_bot_choices();
        int bot_possible_choices[] = {-1, -2, -3};
        int arr_length = bot_possible_choices.length;
        Randomizu.randomize(bot_possible_choices, arr_length);
        int bot_choice = bot_possible_choices[1];

        if(bot_choice == -1){
            System.out.println("Bot Choice: Bato");
        }
        else if(bot_choice == -2){
            System.out.println("Bot Choice: Papel");
        }
        else{
            System.out.println("Bot Choice: Gunting");
        }
            
        int score = BatoPapelGunting.pointBPG(bot_choice, user_choice);

        // Creating a calculating function for the value of the returned addends to determine the result
        
        if(score > 0 && score < 2){
            System.out.println("You Win!");
            return +1;
        }
        else if(score < 0 && score > -2){
            System.out.println("You Lose");
            return -1;
        }
        else if(score == 2) // No. 2 and -2 are outliers because of the difference in the calculation of the value without the use of absolute functions to determine the results.
        // For more information, a sheet of paper included with the permutation of all the sequence is included below.
        {
            System.out.println("You Lose!");
            return -1;
        }
        else if(score == -2){
            System.out.println("You Win!");
            return +1;
        }
        else{
            System.out.println("Draw!");
        }
        return 0;
    }
    public static void decideWinner(int final_score){
        if(final_score > 0){
            System.out.println("Congratulations you have won!");
        }
        else if(final_score < 0){
            System.out.println("You lost! Better luck next time!");
        }
        else{
            System.out.println("Draw!");
        }
    }
}