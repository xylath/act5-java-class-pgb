package Randomizu;

import java.util.Random;

public class Randomizu{
    
    public static void randomize(int arr[], int arr_length){
        // Create a new index_randomizer for the random position the array element will take
        Random rand_index = new Random();
        // Define the temp_variable to store the array to switch position
        int temp;

        for(int counter = arr_length - 1; counter > 0; counter--){

            // Declaring the random indexer for the value
            int random_index = rand_index.nextInt(counter + 1);
            // Created a switching function where we can store the value and switch the values of the next variables to a random position by the random function
            temp = arr[counter];
            arr[counter] = arr[random_index];
            arr[random_index] = temp;
        }
    }
}
